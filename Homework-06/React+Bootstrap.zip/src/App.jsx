// import React from "react";
import Moot from "./Moot";

export default function App() {
	return (
		<div>
			<h1 className="text-center mt-4">JSX and Components</h1>
			<p className="text-center  text-primary">
				Exercise (make it responsive on every device)
			</p>
			<Moot />
		</div>
	);
};
          